FactoryBot.define do
  factory :comment do
    body "this is a comment"
  end
end
