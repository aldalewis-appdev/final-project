FactoryBot.define do
  factory :like do
  end
end
